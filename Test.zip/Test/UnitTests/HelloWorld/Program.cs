﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            ++i;
            //List<int> li = new List<int>();
            //li.Add(0);
            //_get(li[0]++);
            //if (li.Count == 0 && (li[0] += 10) > 0)
                Console.WriteLine("Hello, World!");
        }
        static int _get(int val) { return val; }
    }
}
