﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniSharping
{
    public enum Enum : byte
    {
        Undefined = 0,
        First = 1,
        Second = 2,
        Third, // = 3,
        Forth = 4,
        Misc = First | Forth,
        Misc2 = Second + Forth,
        Misc3 = Class1.ConstrInt * 2
    }
}
