﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UniSharping.Generic
{
    class ClassGenerics1<T>
    {
        public T BaseObject;
    }

    class ClassGenerics2 : ClassGenerics1<Class1>
    {
        public override string ToString()
        {
            string str = BaseObject.TestMethodString("123");
            return str + BaseObject.IntVal.ToString();
        }
    }
}
