﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniSharping
{
    public class Attr : Attribute
    {

    }

    [Attr()]
    public class ChildClass1 : Class1, IComparable<ChildClass1>, IEnumerable<Class1>
    {
        static ChildClass1()
        {

        }
        public ChildClass1(short intVal) : base(intVal)
        {
            if (Class1 != null)
                if (Class1.Sub.V1 == 0)
                    Class1.Sub.Func();
        }

        public Class1 Class1 = null;
        public int Value;

        class SubClass : Interf
        {
            public int Val
            {
                get
                {
                    throw new NotImplementedException();
                }
                set
                {
                    throw new NotImplementedException();
                }
            }
        }

        public override void TestExceptions()
        {
            base.TestExceptions();
        }

        public override int NoExceptionMethod()
        {
            try
            {
                base.NoExceptionMethod();
            }
            catch { }
            throw new NotSupportedException();
        }

        public int CompareTo(ChildClass1 other)
        {
            return base.CompareTo(other);
        }

        public List<Class1> Classes1 = new List<Class1>();

        public IEnumerator<Class1> GetEnumerator()
        {
            return Classes1.GetEnumerator();
        }
#if !UNISHARPING
        IEnumerator IEnumerable.GetEnumerator()
        {
            return Classes1.GetEnumerator();
        }
#endif
    }
}
