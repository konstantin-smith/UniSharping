﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Compression;
using System.ComponentModel;
using System.Threading;

namespace UniSharping.Subns
{
    public class Class4
    {

        static event EventHandler<EventArgs> m_Event;
        public static event EventHandler<EventArgs> EventTest
        {
            add { m_Event += value; }
            remove { m_Event -= value; }
        }
        public static void TestEvent()
        {
            for (int i = 0; i < 10; i++)
                if (m_Event != null)
                    m_Event(null, new ProgressChangedEventArgs(i * 10, null));
        }

        void testShort(short? sh) { }
        void testDouble(Double? d) { }

        void TestAllNums()
        {
            testShort(1);
            testDouble(1);
        }


        public static event ProgressChangedEventHandler Progress;

        public static void TestProgress()
        {
            for (int i = 0; i < 10; i++)
                if (Progress != null)
                    Progress(null, new ProgressChangedEventArgs(i * 10, null));
        }

        static Enum m_eee = Enum.First;
        public static void TestEnums()
        {
            Enum ee = (Enum)( m_eee | Enum.Second);
            if (ee == Enum.Third)
                Console.Write("OK ");
            Console.Write("ee = {0}", ee);

            ee |= Enum.Forth;
            Console.WriteLine(", ee + forth = {0}", ee);

            Console.WriteLine("Or enums: {0}", AddToEnum(Enum.First, Enum.Forth));

            if ((ee = Enum.Forth) != Enum.First)
                Console.Write("");

            Console.WriteLine("{0} | {1} = {2}", m_eee, Enum.Second, (m_eee | Enum.Second).ToString());

            object ee2 = (Enum)System.Enum.Parse(typeof(Enum), ee.ToString(), false);
            if ((Enum)ee2 != ee)
                Console.Write(" ERROR: {0} != {1} ", ee2, ee);
            object ee3 = ee;
            Console.Write(" ee3 = {0}", ee3);
        }

        static string[] m_Strings = new string[] { "111", "222", "333" };

        // это была проверка "одинаковых" имён, разных в .NET и одинаковых в Java
        //public static int Summa(List<int> li)
        //{
        //    int r = 0; foreach (var a in li) r += a;
        //    return r;
        //}
        //public static long Summa(List<long> li)
        //{
        //    long r = 0; foreach (var a in li) r += a;
        //    return r;
        //}
        //public static long Summa(List<short> li)
        //{
        //    short r = 0; foreach (var a in li) r += a;
        //    return r;
        //}

        public static Enum AddToEnum(Enum e1, Enum e2)
        {
            return e1 | e2;
        }

        public enum SubEnum
        {
            SUndefined = 0,
            SFirst = 1,
            SSecond = 2,
            SThird = 3,
            SForth = 4,
            Value = 5
        }
    }
}
