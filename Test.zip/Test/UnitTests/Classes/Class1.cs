﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.ComponentModel;
using System.Collections;
using UniSharping.Subns;

namespace UniSharping
{
    /// <summary>
    /// Это самый лучший класс в мире!!!
    /// </summary>
    public class Class1 : IDisposable, IComparable<Class1>
    {
        /// <summary>
        /// Это просто поле
        /// </summary>
        public int IntVal;
        /// <summary>
        /// А это свойство на чтение и запись
        /// </summary>
        public int IntProp
        {
            get { return m_IntProp; }
            set { m_IntProp = value; }
        }
        int m_IntProp;

        public int IntProp2 { get; set; } = 100;


        public string StringVal;
        public string File = "123";

        public SubClass Sub;
        /// <summary>
        /// Свойство энумератора
        /// </summary>
        public Enum EnumProp = Enum.First;

        public override int GetHashCode()
        {
            return m_IntProp;
        }
        public Class1 RefToClass;
        public SubClass[] SubClassArray;

        public override bool Equals(object obj)
        {
            if (obj is Class1)
                return (obj as Class1).m_IntProp == m_IntProp;
            return base.Equals(obj);
        }
        /// <summary>
        /// Это индексатор,
        /// причём комментарий в две строки
        /// </summary>
        /// <param name="ind">индекс</param>
        /// <returns>возвращает целочисленное значение</returns>
        public int this[int ind]
        {
            get { return IntVal + ind; }
            set { IntVal = value + ind; }
        }

        public int TestMethod(int super)
        {
            return IntVal + IntProp + super;
        }

        public string TestMethodString(string var)
        {
            ++IntProp;

            if (var == "true") return var.TrimEnd();
            if (var.Length == 0) return String.Empty;

            StringBuilder res = new StringBuilder();
            res.AppendFormat("{0} + test ", var);
            res.Remove(res.Length - 1, 1);
            res.Append('?');
            res.Length -= 1;

            int i, j;
            res.Remove(i = 0, j = 2);
            i = j = 5;
            var s = res.ToString();
            s += this.StringVal;

            Console.Write("StringBuilder: ");
            for (i = 0; i < res.Length; i++)
                Console.Write(res[i]);
            Console.WriteLine();

            return s ?? "null";
        }

        public class MyException : Exception
        {
            public MyException(string str) : base(str) { }
        }

        public virtual void TestExceptions()
        {
            int i = 2 * 3 + 4 * 2;
            int j = i == 14 ? 200 + i : 2000;
            if (i != 14 || j != i + 200)
                throw new MyException("Error");
            else
                throw new MyException("OK");
        }

        public void TestException1()
        {
            int i = 0, j = i;
            Class1 cla = new Class1();
            string str = cla is Class1 ? "class1" : "not";

            TestException2();
            throw new FileNotFoundException();
        }
        public void TestException2()
        {
            TestException1();
            throw new Exception("ERROR");
        }

        public virtual int NoExceptionMethod()
        {
            return 10;
        }

        static public implicit operator short(Class1 cla)
        {
            return unchecked((short)cla.IntVal);
        }

#if PYTHON 
        public Class1(short intVal = 0) 
#else
        public Class1()
            : this(0)
        {
        }
        public Class1(short intVal)
#endif
        { 
            IntVal = intVal;
            SubClassArray = new SubClass[10];
            //Sub = new SubClass();
        }


        ~Class1()
        {
            StringVal = null;
        }

        public static Class1 Global = new Class1(100);

        public static Class1 operator +(Class1 c1, Class1 c2)
        {
            return new Class1((short)(c1.IntVal + c2.IntVal));
        }
        public static Class1 operator ++(Class1 c1)
        {
            c1.IntVal++; return c1;
        }

        void IDisposable.Dispose()
        {
            Console.Write(Global);
            Console.WriteLine(" Dispose Class1 {0} ", this);
            try
            {
                if (IntVal == 111111)
                    throw new NotImplementedException("Test");
            }
            catch(NotImplementedException)
            {
                throw;
            }
            GC.SuppressFinalize(this);
        }

        public override string ToString()
        {
            string res = (StringVal ?? "") + IntVal.ToString();
            if (string.IsNullOrEmpty(res))
                throw new Exception("NULL!!!");
            return res;
        }
        public string ToString(int self)
        {
            return self.ToString();
        }

        public static int Sum(params int[] args)
        {
            int res = 0;
            if (args != null)
                for (int i = 0; i < args.Length; i++) res += args[i];
            return res;
        }

        public class SubClass
        {
            public int V1;
            public double V2;
            public static Class4.SubEnum TestSubEnums(Class4.SubEnum e1, Class4.SubEnum e2, Class4.SubEnum e3)
            {
                return (e1 | e2) & e3;
            }
            public static Class4.SubEnum SubClassStatItem = Class4.SubEnum.SUndefined;
            public static string SubStatString;
            public void Func() { }
            static SubClass() 
            {
                SubStatString = "Kostia";
            }

            public class SubSubClass : IComparable<SubSubClass>
            {
                public int V1;
                public double V2;
                public override string ToString()
                {
                    return V1.ToString();
                }
                public static int Level3Val = 1 + 2;
                public static void HelloWorld()
                {
                    Console.WriteLine("Hellow, World!");
                }

                int IComparable<SubSubClass>.CompareTo(SubSubClass other)
                {
                    return V1 - other.V1;
                }
            }
        }

        public interface Interf
        {
            int Val { get; set; }
        }

        public int CompareTo(Class1 other)
        {
            if (IntVal < other.IntVal) return -1;
            return IntVal == other.IntVal ? 0 : 1;
        }

        static Class1()
        {
            StatList = new List<string>();
            foreach (var s in "1111;22222;33333;44444;55555;66666".Split(';'))
                StatList.Add(s);

            SubClass sc = new SubClass() { V1 = 19, V2 = 20 };

            if (SubClass.SubSubClass.Level3Val > 0)
                SubClass.SubSubClass.HelloWorld();
        }
        public static List<string> StatList;

        public const int ConstrInt = 100;
    }

    public delegate int SampleDelegate(int val);
}
