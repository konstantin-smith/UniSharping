﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace UnitTests
{
    [TestClass]
    public class OperatorUnitTest
    {
        [TestMethod]
        public void TestFor()
        {
            List<int> li = new List<int>();
            int i; for (i = 0; i < 10; i++) li.Add(i);
            for (i = 0; i < li.Count; i++)
            {
            }
            Assert.IsTrue(i == 10 && li.Count == 10 && li[li.Count - 1] == 9);
            i = 0;
            foreach (var v in li) i++;
            Assert.AreEqual(i, li.Count);

            for (i = 0; i < li.Count; i++)
            {
                if (i == 0) li.Add(11);
            }
            Assert.IsTrue(i == 11 && li.Count == 11 && li[10] == 11);
        }
        [TestMethod]
        public void TestSwitch()
        {
            UniSharping.Enum ee = UniSharping.Enum.First;
            bool ok = false;
            switch (ee)
            {
                case UniSharping.Enum.First: ok = true; break;
                case UniSharping.Enum.Forth:
                case UniSharping.Enum.Second:
                    if (ee == UniSharping.Enum.Misc)
                    {
                        Assert.Fail();
                        break;
                    }
                    break;
                default:
                    Assert.Fail();
                    break;
            }
            Assert.IsTrue(ok);
        }

        [TestMethod]
        public void TestUsing()
        {
            m_Disposed = false;
            using (var d = new ADisp())
            { }
            Assert.IsTrue(m_Disposed);
        }
        static bool m_Disposed;
        class ADisp : IDisposable
        {
            public void Dispose()
            {
                m_Disposed = true;
            }
        }

        class MyException : Exception { }
        [TestMethod]
        public void TestException()
        {
            bool ok = false;
            try
            {
                throw new MyException();
            }
            catch (MyException ex)
            {
                ok = true;
            }
            catch(OverflowException e)
            {
            }
            catch (Exception e)
            {
            }
            Assert.IsTrue(ok);
        }

#if PYTHON
        object m_Lock = new object();
#else 
        ADisp m_Lock = new ADisp();
#endif
        [TestMethod]
        public void TestLock()
        {
            bool ok = false;
            lock(m_Lock)
            {
                ok = true;
            }
            Assert.IsTrue(ok);
        }

    }
}