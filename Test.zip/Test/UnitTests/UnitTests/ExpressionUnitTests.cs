﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTests
{
    [TestClass]
    class ExpressionUnitTests
    {
        [TestMethod]
        public void TestPostIncrements()
        {
            List<int> li = new List<int>();
            li.Add(0);
            if (++li[0] > 0)
                Assert.IsTrue(li[0] == 1);
            else
                Assert.Fail();
            if ((li[0] += 1) > 0)
                Assert.IsTrue(li[0] == 2);
            else
                Assert.Fail();

#if !PYTHON
            if (li.Count == 0 && (li[0] += 10) > 0)
            {
                Assert.Fail();
            }
            Assert.IsTrue(li[0] == 2);

            //if (li[0]++ > 0)  
            //    Assert.IsTrue(li[0] == 2);
            //Assert.IsTrue(li[0] == 3);
#endif
            int i = 0;
            int j = _getVal(++i);
            Assert.AreEqual(j, 1);
            j = _getVal(j += 10);
            Assert.AreEqual(j, 11);

            li[0] = 0;
            j = _getVal(++li[0]);
            Assert.AreEqual(j, 1);
            ++j;
            Assert.AreEqual(j, 2);
            //j = _getVal(li[0]++);  так больше делать нельзя - ругаемся
            //Assert.AreEqual(j, 1); Assert.IsTrue(li[0] == 2);
        }

        int _getVal(int val) { return val; }

        [TestMethod]
        public void TestEquation()
        {
            // а питон здесь ругается!
#if !PYTHON
            int i = 0, j = 0;
            if(i > 0 && (j = 1) > 0)
            {
                Assert.Fail();
            }
            Assert.IsTrue(j == 0); // !!!
#endif
        }
    }
}
