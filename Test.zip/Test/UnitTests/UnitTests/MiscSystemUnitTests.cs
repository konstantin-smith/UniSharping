﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml;
using System.IO;
using System.Reflection;
using System.Threading;
using UniSharping;
using UniSharping.Subns;

namespace UnitTests
{
    [TestClass]
    public class MiscSystemUnitTests
    {
        [TestMethod]
        public void TestDate()
        {
            DateTime dt = new DateTime(2018, 09, 7);
            Assert.IsTrue(dt.DayOfWeek == DayOfWeek.Friday);
            Assert.IsTrue(dt.Day == 7 && dt.Month == 9 && dt.Year == 2018);
        }


        [TestMethod]
        public void TestNullable()
        {
            int? i = 10;
            Assert.IsTrue(i.HasValue && i.Value == 10 && i == 10);

            UniSharping.Enum? e = UniSharping.Enum.First;
            Assert.IsTrue(e.HasValue && e.Value == UniSharping.Enum.First);

            Class4.SubEnum? ee = (Class4.SubEnum)System.Enum.ToObject(typeof(Class4.SubEnum), 1L);
            Assert.IsTrue(ee != null && ee == Class4.SubEnum.SFirst);

            ICollection<KeyValuePair<int, IList<object>>> tmp = new List<KeyValuePair<int, IList<object>>>();
            Assert.IsTrue(tmp.Count == 0);

            byte[] data = new byte[sizeof(short)];
            Assert.IsTrue(data.Length == 2);


            Class4.SubEnum se = Class4.SubEnum.Value;
            Assert.IsTrue(se == Class4.SubEnum.Value);

            se = Class4.SubEnum.SFirst | Class4.SubEnum.SSecond;
            Assert.IsTrue(se == Class4.SubEnum.SThird);
        }
        [TestMethod]
        public void TestLongs()
        {
            long lo = 1000;
            Assert.IsTrue(lo < 0xFFFFFFFF);
        }
        [TestMethod]
        public void TestDoubles()
        {
            double d = Math.Log(16, 2);
            Assert.IsTrue(d == 4, string.Format("{0} != 4", d));
            double d2 = Math.Log(16) / Math.Log(2);
            Assert.IsTrue(d2 == 4, string.Format("{0} != 4", d2));
            Assert.IsFalse(Double.IsInfinity(d));

            double d1 = double.PositiveInfinity;
            Assert.IsTrue(double.IsPositiveInfinity(d1));
        }

        [TestMethod]
        public void TestParams()
        {
            int x = Class1.Sum(1, 2, 3);
            Assert.IsTrue(x == 6);
            x = Class1.Sum();
            Assert.IsTrue(x == 0);
            x = Class1.Sum(new int[] { 1, 2, 3 });
            Assert.IsTrue(x == 6);
        }



        [TestMethod]
        public void TestFormats()
        {
            StringBuilder tmp = new StringBuilder();
            string str = "123"; int i = 4;
            tmp.AppendFormat("{0}", str ?? i.ToString());
            Assert.IsTrue(tmp.ToString() == str);
        }

        [TestMethod]
        public void TestUnsigned()
        {
            uint x = 0xFFFFFFFF;
            uint y = x >> 8;
            Assert.IsTrue(y == 0xFFFFFF);

            ushort ux = 0xFFFF;
            ushort uy = (ushort)(ux >> 8);
            Assert.IsTrue(uy == 0xFF);
        }

        [TestMethod]
        public void TestBitConversions()
        {
            ushort us = 0xFF00;
            byte[] buf = BitConverter.GetBytes(us);
            Assert.IsTrue(buf.Length == 2);
            ushort us1 = BitConverter.ToUInt16(buf, 0);
            Assert.IsTrue(us1 == us);

            double dbl = 123.456;
            buf = BitConverter.GetBytes(dbl);
            Assert.IsTrue(buf.Length == 8);
            double dbl1 = BitConverter.ToDouble(buf, 0);
            Assert.IsTrue(dbl1 == dbl);

            Assert.IsTrue(buf[0] == 0x77 && buf[7] == 0x40);
        }

        [TestMethod]
        public void TestMemoryStream()
        {
            using (MemoryStream mem = new MemoryStream())
            {
                for (int i = 0; i < 10; i++) mem.WriteByte((byte)0);
                Assert.IsTrue(mem.Length == 10 && mem.Position == mem.Length);
                mem.Position = 1;
                byte b = (byte)mem.ReadByte();
                Assert.IsTrue(b == 0 && mem.Position == 2);
                mem.Position = 1;
                for (int i = 0; i < 10; i++) mem.WriteByte((byte)(i + 1));

                mem.Position = 1;
                b = (byte)mem.ReadByte();
                Assert.IsTrue(b == 1 && mem.Position == 2 && mem.Length == 11);
            }
        }


#if !PYTHON

        [TestMethod]
        public void TestArrays()
        {
            int[] arr = new int[10];
            for (int i = 0; i < arr.Length; i++) arr[i] = i;
            Array.Resize<int>(ref arr, 5);
            Assert.AreEqual(arr.Length, 5);
            Array.Resize<int>(ref arr, 15);
            Assert.AreEqual(arr.Length, 15);

            int[] arr2 = new int[10];
            Array.Copy(arr, 1, arr2, 0, 2);
            Assert.IsTrue(arr2.Length == 10 && arr2[0] == 1 && arr2[1] == 2 && arr2[2] == 0);

            int ii = Array.IndexOf(arr, 1);
            int jj = Array.IndexOf(arr, 1, 10);
            Assert.IsTrue(ii == 1 && jj < 0);
        }


        [TestMethod]
        public void TestReflection()
        {
            var typ = GetType();
            var typ2 = typeof(MiscSystemUnitTests);
            Assert.AreEqual(typ, typ2);
            Assert.IsTrue(typ.Name.EndsWith("MiscSystemUnitTests"));
            Assert.IsTrue(GetType().FullName.EndsWith("MiscSystemUnitTests"));

            //foreach (var cii in typeof(Class1).GetConstructors())
            //{
            //    Console.WriteLine("");
            //}
            //try
            //{
            ConstructorInfo ci = typeof(Class1).GetConstructor(new Type[] { typeof(Int16) });
            Assert.IsTrue(ci != null); // && ci.GetParameters().Length == 1);

            object o = ci.Invoke(new object[] { (short)123 });
            Assert.IsTrue(o != null && o.ToString() == "123");
            //}
            //catch(Exception ex)
            //{
            //Console.WriteLine(ex);
            //Assert.Fail();
            //}
        }

        Guid m_Guid;
        DateTime m_DateTime;
        static DateTime m_GlobalDateTime;

        [TestMethod]
        public void TestGuid()
        {
            Guid g = new Guid("79C5566B-EC4E-4FD4-B33B-BAF213C23ADA");  //Guid.NewGuid();
            Guid g2 = new Guid(g.ToString());
            Assert.IsTrue(g2 == g);

            byte[] arr = g.ToByteArray();
            Assert.IsTrue(arr[0] == 0x6B && arr.Length == 16);

            Guid g3 = new Guid(arr);
            Assert.IsTrue(g == g3 && g3 != Guid.Empty);
        }


        [TestMethod]
        public void TestServiceMisc()
        {
            GC.SuppressFinalize(this);
            GC.Collect();
            long mem = GC.GetTotalMemory(false);
            Assert.IsTrue(mem > 0);

            string curDir = AppDomain.CurrentDomain.BaseDirectory;
            Console.WriteLine("Basedir={0}, MachineName={1}, UserName={2} ", curDir, Environment.MachineName, Environment.UserName);
            Assert.IsNotNull(curDir);
        }
        [TestMethod]
        public void TestThread()
        {
            m_Char = (char)0;
            Thread thr = new Thread(_runner);
            thr.Start('*');
            while (thr.IsAlive)
            {
                Thread.Sleep(100);
            }
            Assert.IsTrue(m_Char == '*');
        }

        char m_Char;

        void _runner(object delim)
        {
            m_Char = (char)delim;
        }

        [TestMethod]
        public void TestUri()
        {
            //string
            string str = "https://stackoverflow.com:8080/questions/16031418/what/?get=абв&set=456#ФРАГМЕНТ";
            Uri u1 = new Uri(str);
            Uri u2;
            if (!Uri.TryCreate(str, UriKind.RelativeOrAbsolute, out u2))
                Assert.Fail();
            else
                Assert.AreEqual(u1, u2);

            Console.WriteLine("\r\nAbsolute: {0} ", u1.AbsoluteUri);
            Console.WriteLine("Auth:{0} Schema:{1} Host:{2} Port:{3} Frag:{4} Path:{5} Query:{6} ",
                u1.Authority, u1.Scheme, u1.Host, u1.Port, u1.Fragment, u1.LocalPath, u1.Query);
        }


        [TestMethod]
        public void TestWeb()
        {
            //System.Web.UrlEncode uu = new System.Web.UrlEncode();
        }
#endif
    }
}

