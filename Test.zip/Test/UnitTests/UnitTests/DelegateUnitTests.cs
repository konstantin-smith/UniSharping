﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UniSharping;

namespace UnitTests
{
#if !PYTHON
    [TestClass]
    public class DelegateUnitTests
    {
        [TestMethod]
        public void TestLinq()
        {
            Class1[] arr = new[] { new Class1(10), new Class1(20), new Class1(30) };
            List<Class1> li = new List<Class1>(arr);

            var sel = li.Select(x => x.IntVal);
            int k = 0;
            foreach (var v in sel.ToList())
                Assert.AreEqual(li[k++].IntVal, v);
            Assert.IsNull(li.ElementAtOrDefault(li.Count));
        }

        [TestMethod]
        public void TestListPredicates()
        {
            //int[] empty = new int[0];
            List<int> empty = new List<int>();
            int i0 = empty.LastOrDefault();
            Assert.AreEqual(i0, 0);

            List<int> li = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            IEnumerable<int> li2 = li.Concat(new List<int>(new int[] { 11, 12 }));
            Console.Write("List0: ");
            li.ForEach((x) => Console.Write("{0} ", x));
            //li.ForEach((x) => Console.Write($"{x} {li.Count} {x}!!!!"));

            Console.Write(", count(even)={0}, first={1}", li2.Count(x => (x & 1) == 1), li2.FirstOrDefault(x => x == 3));

            Assert.IsTrue(li.Exists((x) => { return x == 5; }));
            int ind = li.FindLastIndex(li.Count - 1, 7, (x) => { return x == 5; });
            Assert.AreEqual(ind, 4);

            int k = 0;
            foreach (var v in li.FindAll(x => (x & 1) == 1))
            {
                Assert.AreEqual((k++) * 2 + 1, v);
            }
        }

        delegate int Oper(int a, int b);
        static int DoOper(Oper op, int a, int b)
        {
            return op(a, b);
        }

        [TestMethod]
        public void TestDelegateAsArg()
        {
            int ret = DoOper(delegate (int a, int b) { return a + b; }, 1, 1);
            Assert.IsTrue(ret == 2);
        }


        delegate int TestDelegate<T>(T s);
        delegate void TestDelegate2<T>(T s) where T : Class1;
        static int M(string s)
        {
            Console.WriteLine(s);
            return 0;
        }
        public void TestLambdas()
        {
            // Original delegate syntax required 
            // initialization with a named method.
            TestDelegate<string> testDelA = new TestDelegate<string>(M);

            string post = " !!!";

            // C# 2.0: A delegate can be initialized with
            // inline code, called an "anonymous method." This
            // method takes a string as an input parameter.
            TestDelegate<int> testDelB = delegate(int s) { Console.WriteLine("{0} {1}", s, post); return 0; };
            m_Events += delegate(int s) { Console.WriteLine("{0} {1}", s, post); return 0; };

            // C# 3.0. A delegate can be initialized with
            // a lambda expression. The lambda also takes a string
            // as an input parameter (x). The type of x is inferred by the compiler.
            TestDelegate<string> testDelC = x => { Console.WriteLine(x + post); Console.WriteLine(post); return 1; };

            // Invoke the delegates.
            testDelA("Call delegate");
            testDelB(11111);
            Console.WriteLine(testDelC("Call lambda"));

            _callLambda<float>(x => { Console.Write(x); return 12; }, 10.4F);
            _callLambda<double>(delegate(double s) { Console.WriteLine("{0} {1}", s, post); return 0; }, 20.8);

            TestDelegate2<Class1> ddd = x => { x.TestMethodString("From delegate"); };
            ddd(new Class1(456));

        }

        event TestDelegate<int> m_Events;

        static int _callLambda<T>(TestDelegate<T> d, T val)
        {
            return d(val);
        }
    }
#endif
}
