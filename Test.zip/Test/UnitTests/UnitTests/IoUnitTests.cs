﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace UnitTests
{
#if !PYTHON
    [TestClass]
    public class IoUnitTests
    {
        [TestMethod]
        public void TestFileStream()
        {
            string fname = "test.txt";
            if (File.Exists(fname))
                File.Delete(fname);
            Assert.IsFalse(File.Exists(fname));

            byte[] arr = new byte[256];
            for (int i = 0; i < arr.Length; i++) arr[i] = (byte)i;

            File.WriteAllBytes(fname, arr);

            FileInfo fi = new FileInfo(fname);
            Assert.IsTrue(fi.Exists && fi.Length == arr.Length);

            using (FileStream f = File.Open(fname, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                Assert.IsTrue(f.Length == arr.Length);
                f.Seek(128, SeekOrigin.Begin);
                byte b = (byte)f.ReadByte();
                Assert.IsTrue(b == 128);

                Stream bsre = f;
                bsre.SetLength(100);
            }

            fi = new FileInfo(fname);
            Assert.AreEqual(fi.Length, 100);

            using (StreamReader sr = new StreamReader(fname, Encoding.ASCII))
            {
                int i = sr.Read();
                Assert.IsTrue(i == 0);
            }

                File.Delete(fname);
            Assert.IsFalse(File.Exists(fname));

            SeekOrigin so = SeekOrigin.Begin;
            switch(so)
            {
                case SeekOrigin.Begin: so = SeekOrigin.End; break;
                case SeekOrigin.Current: Assert.Fail(); break;
                default: Assert.Fail(); break;
            }
        }

        class MyStream : Stream
        {
            public override bool CanRead => throw new NotImplementedException();
            public override bool CanSeek => throw new NotImplementedException();
            public override bool CanWrite => throw new NotImplementedException();
            public override void Close()
            {
                base.Close();
            }
            public override long Position { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
            public override void SetLength(long value)
            {
                throw new NotImplementedException();
            }
            public override long Length => throw new NotImplementedException();
            public override int Read(byte[] buffer, int offset, int count)
            {
                throw new NotImplementedException();
            }
            public override void Write(byte[] buffer, int offset, int count)
            {
                throw new NotImplementedException();
            }
            public override long Seek(long offset, SeekOrigin origin)
            {
                throw new NotImplementedException();
            }
            public override void Flush()
            {
                throw new NotImplementedException();
            }
        }


        [TestMethod]
        public void TestFileDirectory()
        {
            string dname = Path.Combine(Directory.GetCurrentDirectory(), "dir");
            Assert.IsTrue(Path.IsPathRooted(dname));
            if (Directory.Exists(dname))
                Directory.Delete(dname, true);
            DirectoryInfo di = new DirectoryInfo(dname);
            Assert.IsFalse(Directory.Exists(dname) || di.Exists);

            di.Create();
            di = new DirectoryInfo(dname); // хотя лучше использовать Refresh()

            Assert.IsTrue(di.Exists && di.CreationTime.Date == DateTime.Today);

            string fname = Path.Combine(dname, "file.dat");
            File.WriteAllText(fname, "Kostian!");
            Assert.IsTrue(Path.GetExtension(fname) == ".dat");

            di = new DirectoryInfo(dname); // хотя лучше использовать Refresh()
            FileInfo fi = new FileInfo(fname);
            Assert.IsTrue(fi.Exists && (fi.LastWriteTime - di.LastWriteTime).TotalSeconds < 1);

            Assert.IsTrue(fi.DirectoryName == di.FullName);

            Directory.Delete(dname, true);
            Assert.IsFalse(Directory.Exists(dname));
        }

    }
#endif
}
