﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using UniSharping;

namespace UnitTests
{
    [TestClass]
    public class CollectionUnitTests
    {
        int m_Sum;

#if !PYTHON
        [TestMethod]
        public void TestEnumerables()
        {
            List<int> li = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            IEnumerable<int> li2 = li.Concat(new List<int>(new int[] { 11, 12 }));
            Assert.IsTrue(li.Count + 2 == li2.Count());
            Assert.IsTrue(li2.Count(x => (x & 1) == 1) == 6);
            Assert.IsTrue(li2.FirstOrDefault(x => x == 3) == 3);

            m_Sum = 0;
            li.ForEach((x) => m_Sum += x);
            Assert.IsTrue(m_Sum == 55);
            //li.ForEach((x) => Console.Write($"{x} {li.Count} {x}!!!!"));

            Assert.IsTrue(li.Exists((x) => { return x == 5; }));

            int ind = li.FindLastIndex(li.Count - 1, 7, (x) => { return x == 5; });
            Assert.IsTrue(ind == 4);

            //Console.Write("evens: ");
            //foreach (var v in li.FindAll(x => (x & 1) == 1))
            //    Console.Write("{0} ", v);
            //Console.WriteLine();


            Class1[] arr = new[] { new Class1(10), new Class1(20), new Class1(30) };
            List<Class1> li0 = new List<Class1>(arr);

            var sel = li0.Select(x => x.IntVal);
            List<int> tli = sel.ToList();
            Assert.IsTrue(tli.Count == 3 && tli[0] == 10);
            Assert.IsTrue(li0.ElementAtOrDefault(2).IntVal == 30);

            //int[] empty = new int[0];
            List<int> empty = new List<int>();
            Assert.IsTrue(new List<int>().LastOrDefault() == 0);

            KeyValuePair<int, string>[] karr = new KeyValuePair<int, string>[100];

            Assert.IsTrue(arr[0][0] == 10);
            arr[0][0] += 100;
            Assert.IsTrue(arr[0][0] == 110);

            li.Clear();
            IEnumerable<int> iii = new int[] { 5, 4, 3 };
            li.AddRange(iii);
            li.InsertRange(0, new int[] { 2, 0, 1 });
            li.Sort();
            Assert.IsTrue(li[0] == 0);
            li.RemoveRange(1, 2);
            Assert.IsTrue(li.Count == 4 && li[1] == 3);

            // нетипизированный 
            System.Collections.IList nli = li;
            nli.Insert(1, 1000);
            Assert.AreEqual(nli[0], li[0]);

            li = new List<int>(new int[] { 2, 0, 1 });
        }
#endif

        [TestMethod]
        public void TestListEnums()
        {
            List<UniSharping.Enum> elist = new List<UniSharping.Enum>();
            elist.Add(UniSharping.Enum.First); elist.Add(UniSharping.Enum.Second);
            Assert.IsTrue(elist.Contains(UniSharping.Enum.First));
            int i = elist.IndexOf(UniSharping.Enum.Second);
            Assert.AreEqual(i, 1);
            _testList<UniSharping.Enum>(elist);

            List<string> strli = new List<string>();
            strli.Add("KKK"); strli.Add("PPP");
            i = strli.IndexOf("PPP", 1);
            Assert.AreEqual(i, 1);
            Assert.IsTrue(elist.Count > 0);
            _testList<string>(strli);
            _testList2(strli);

            UniSharping.Enum[] arr = new UniSharping.Enum[] { UniSharping.Enum.First, UniSharping.Enum.Second };
            Assert.IsTrue(arr.Length == 2 && arr[0] == UniSharping.Enum.First && arr[1] == UniSharping.Enum.Second);
        }
        static void _testList<T>(ICollection<T> li)
        {
            foreach (var e in li)
                Console.Write("{0} ", e);
            Console.WriteLine();
        }
        static void _testList2(IList<string> li)
        {
            foreach (var e in li)
                Console.Write("{0} ", e);
            Console.WriteLine();
        }

        [TestMethod]
        public void TestEnumerator()
        {
            ChildClass1 enu = new ChildClass1(0);
            enu.Classes1.Add(new Class1(100));
            enu.Classes1.Add(new Class1(200));

            foreach (var v in enu)
            {
                Assert.IsTrue(v.IntVal == 100 || v.IntVal == 200);
                Console.Write("{0} ", v.IntVal);
            }
            Console.WriteLine();

            List<int> li = new List<int>();
            foreach (var ii in new MyEnumerable()) li.Add(ii);
            Assert.IsTrue(li.Count == 2 && li[0] == 1);
        }

        class MyEnumerable : IEnumerable<int>
        {
            class MyEnumerator : IEnumerator<int>
            {
                int i = 0;
                int IEnumerator<int>.Current => i;

#if !JAVA && !PYTHON
                object IEnumerator.Current => i;
#endif

                void IDisposable.Dispose()
                {
                }

                bool IEnumerator.MoveNext()
                {
                    if (i >= 2) return false;
                    i++; return true;
                }

                void IEnumerator.Reset()
                {
                    i = 0;
                }
            }
            public IEnumerator<int> GetEnumerator()
            {
                return new MyEnumerator();
            }
#if !JAVA && !PYTHON
            IEnumerator IEnumerable.GetEnumerator()
            {
                return new MyEnumerator();
            }
#endif
        }

        Dictionary<string, string> m_Dic;
        Dictionary<string, string> Dic
        {
            get
            {
                if (m_Dic == null) m_Dic = new Dictionary<string, string>();
                return m_Dic;
            }
        }

        [TestMethod]
        public void TestDictionaries2()
        {
            Dictionary<short, byte[]> dic = new Dictionary<short, byte[]>();
            byte[] test = new byte[] { 1, 2, 3, 4 };
            dic.Add(10, test);
            foreach (var kp in dic)
            {
                Assert.IsTrue(kp.Key == 10);
                var test2 = kp.Value;
                Assert.IsTrue(test2[0] == test[0]);
            }

            if (Dic.ContainsKey("111"))
            {
                if (Dic["111"] != "111")
                    Dic["111"] = "111";
            }
            else
                Dic.Add("111", "111");
            foreach (var kp in Dic)
                Assert.IsTrue(kp.Key == kp.Value);

            Dictionary<string, double> dic2 = new Dictionary<string, double>();
            dic2.Add("1", 1);
            double sh;
            if (dic2.TryGetValue("1", out sh))
                Assert.IsTrue(sh == 1);
            else
                Assert.Fail();
            if (dic2.TryGetValue("2", out sh))
                Assert.Fail();

            Dictionary<string, double>.KeyCollection keys = dic2.Keys;
            int k = 0;
            foreach (string s in keys) k++;
            Assert.IsTrue(keys.Count == dic2.Count && keys.Count == k);

        }


        [TestMethod]
        public void TestDictionaries()
        {
            Dictionary<int, string> dic = new Dictionary<int, string>(100);
            dic.Add(1, "111");
            dic.Add(2, "222");
            dic.Add(3, "333");
            dic.Remove(2);

            try
            {
                Assert.IsNull(dic[2]);
                //Assert.Fail();  нет, в Java он не выдаёт исключения в этом случае, а просто возвращает null
            }
            catch { }
            string s = null;
            Assert.IsFalse(dic.TryGetValue(2, out s));
            Assert.IsTrue(dic.TryGetValue(1, out s));
            Assert.IsTrue(s == "111");

            Assert.IsTrue(dic.Count == 2);

            Dictionary<int, string> dic3 = new Dictionary<int, string>(dic);
            Assert.IsTrue(dic3.Count == dic.Count);

            Console.Write("\r\nAll items: ");
            foreach (var kp in dic)
                Console.Write("<{0}, {1}> ", kp.Key, kp.Value);

            Console.WriteLine(" = {0} items", dic.Count);

            Dictionary<string, List<short>> dic2 = new Dictionary<string, List<short>>();
            List<short> li = new List<short>(); li.Add(1); li.Add(2);
            dic2.Add("first", li);
            foreach (var kp in dic2.Values)
                foreach (var v in kp) Console.Write(" {0} ", v);

            Console.WriteLine();
            foreach (var kp in dic2)
                foreach (var kp2 in kp.Value) Console.Write("[{0}:{1}] ", kp.Key, kp2);
            Console.WriteLine();

            foreach (var ii in new List<int>(dic.Keys))
                dic[ii] += "!";
            Console.Write("\r\nAll items with '!': ");
            foreach (var kp in dic)
                Console.Write("<{0}, {1}> ", kp.Key, kp.Value);
            Console.WriteLine(" = {0} items", dic.Count);

            SortedDictionary<string, short> sdic = new SortedDictionary<string, short>();
            sdic.Add("111", 1);
            sdic["111"] += 1;
            sdic["111"]++;
            Assert.IsTrue(sdic["111"] == 3);
        }

#if !PYTHON
        [TestMethod]
        public void TestStack()
        {
            Stack<int> st = new Stack<int>();
            st.Push(1); st.Push(2); st.Push(3);
            Assert.IsTrue(st.Count == 3 && st.Peek() == 3 && st.Contains(1));
            st.Pop();
            Assert.IsTrue(st.Count == 2 && st.Peek() == 2 && !st.Contains(3));
        }
#endif

        [TestMethod]
        public void TestSortSimple()
        {
            List<int> li = new List<int>();
            li.Add(10); li.Add(1); li.Add(5);
            li.Sort();
            Assert.IsTrue(li[0] == 1);
            li.Reverse();
            Assert.IsTrue(li[0] == 10);
        }
        [TestMethod]
        public void TestSortClass()
        {
            List<Class1> li = new List<Class1>();
            li.Add(new Class1(10)); li.Add(new Class1(1)); li.Add(new Class1(5));
            //PYTHON: sort(key=attrgetter('int_val'))
            li.Sort();
            Assert.IsTrue(li[0].IntVal == 1);
            li.Reverse();
            Assert.IsTrue(li[0].IntVal == 10);
        }
    }
}
