﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace UnitTests
{
    [TestClass]
    public class MiscUnitTests
    {
        [TestMethod]
        public void TestXml()
        {
            StringBuilder res = new StringBuilder();
            XmlWriterSettings set = new XmlWriterSettings();
            set.Encoding = Encoding.UTF8;
            using (XmlWriter xml = XmlWriter.Create(res, set))
            {
                //xml.WriteStartDocument();
                xml.WriteStartElement("root");
                xml.WriteElementString("test", " 123 ");
                xml.WriteStartElement("test");
                xml.WriteAttributeString("xml", "space", null, "preserve");
                xml.WriteString(" ");
                xml.WriteEndElement();
                xml.WriteStartElement("pref", "test", "namesps");
                xml.WriteAttributeString("attr", "ns", "val");
                xml.WriteEndElement();
                xml.WriteEndElement();
            }
            string xmltext = res.ToString();
            Console.WriteLine("\r\n{0}", xmltext);
            XmlDocument xdoc = new XmlDocument();
            xdoc.LoadXml(xmltext);
            List<string> vals = new List<string>();
            foreach (XmlNode ch in xdoc.DocumentElement)
            {
                vals.Add(ch.InnerText);
            }
            Assert.IsTrue(vals.Count == 3 && vals[0] == " 123 " && vals[1] == " ");

            var nod1 = xdoc.DocumentElement.ChildNodes[0];
            Assert.IsTrue(nod1.LocalName == "test");
        }
        [TestMethod]
        public void TestResources()
        {
#if !CORE && !PYTHON
            string txt = Properties.Resources.text;
            Assert.IsTrue(txt.StartsWith("Это"));
#endif
            Assembly ass = Assembly.GetExecutingAssembly();
            string[] rss = ass.GetManifestResourceNames();
            Assert.IsTrue(rss.Length == 2);

            Stream str = ass.GetManifestResourceStream("UnitTests.Resources.text2.txt");
            //if (str == null)
            //    str = ass.GetManifestResourceStream("text2.txt");
            if (str != null)
            {
                str.Position = 0;
                byte[] dat = new byte[str.Length];
                str.Read(dat, 0, dat.Length);
                string txt2 = Encoding.UTF8.GetString(dat);
                if (txt2[0] == 0xFEFF) txt2 = txt2.Substring(1);
                Assert.IsTrue(txt2.StartsWith("Это"));
            }
            else
                Assert.Fail("Resource not found");

        }
    }
}
