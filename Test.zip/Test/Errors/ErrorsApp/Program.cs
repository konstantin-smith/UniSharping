﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ErrorsApp
{
    class Program
    {
        static void Main(string[] args)
        {
        }

        static int m_Counter = 0;
        static IEnumerable<int> WithYield()
        {
            m_Counter++;
            yield return m_Counter;
        }
        static void WithGoto()
        {
            if (m_Counter > 0) goto end;
            end: Console.Write("!");
        }
        static void WithGotoCase()
        {
            switch(m_Counter)
            {
                case 1: goto case 2;
                case 2: return;
            }
        }
        unsafe static void WithPointers()
        {
            int ab = 32;
            int* p = &ab;
        }
        unsafe static void WithFixed()
        {
            fixed (char* value = "safe")
            {
                char* ptr = value;
                while (*ptr != '\0')
                {
                    Console.WriteLine(*ptr);
                    ++ptr;
                }
            }
        }
        unsafe static int* Find(int* pi, int size, int value)
        {
            for (int i = 0; i < size; ++i)
            {
                if (*pi == value)
                    return pi;
                ++pi;
            }
            return null;
        }
    }
}
